function setup() {
  createCanvas(400, 400);
  let firstDial = new Dial(true, 200, 200)

firstDial.radius = 30
firstDial.segments = 8
firstDial.minAngle = 100
firstDial.maxAngle = 400
  
 let firstButton = new Button("circle", 200, 100) 
 firstButton.radius = 12

 let firstSlider = new Slider("circle", false, 200, 320)
 firstSlider.smooth = true

}

function draw() {
  background(220);
  
}