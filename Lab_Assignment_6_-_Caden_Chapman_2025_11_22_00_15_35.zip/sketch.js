let pumpkinX = [];
let pumpkinY = [];   
let num = 100;

function setup() { 
  console.log(pumpkinX, pumpkinY);
  createCanvas(400, 400);
  for(let i = 0; i<num; i++) { 
  pumpkinX[i] = -100;
  pumpkinY[i] = -100;
  }
}

function draw() { 
  background(0);
  fill(255, 165, 0);
  noStroke();
  for (let n=0; n<pumpkinX.length; n++) { 
     pumpkinX[pumpkinX.length-1] = mouseX;
     pumpkinY[pumpkinY.length-1] = mouseY;
     circle(pumpkinX[n], pumpkinY[n],40);

  
  }
}