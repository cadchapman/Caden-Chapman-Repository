function setup() {
  createCanvas(400, 400);
  background(220);
  fill(0);
  
  strokeWeight(5);
  stroke(0, 0, 255);
  for (let x=0; x<5; x++){ 
   line(x*5, 0, width+(x*5), height);
  }
}

function draw() {
  if (keyIsPressed){ 
    if(key == "c"){
  background(220);
    circle(mouseX,mouseY,20);
      } else if (key === "f"){ 
        fill(random(256));
      }
  }
 if (mousePressed) { 
   circle(mouseX, mouseY, 10);
 }
}

function keyPressed() {  
  
  
}

function mousePressed() { 

}